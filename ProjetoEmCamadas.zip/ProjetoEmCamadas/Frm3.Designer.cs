﻿
namespace _3B2GABRIELLEONARDO17
{
	partial class FrmComChave
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.grpBox_turma = new System.Windows.Forms.GroupBox();
			this.label3 = new System.Windows.Forms.Label();
			this.btn_CadastrarTurma = new System.Windows.Forms.Button();
			this.txt_serieTurma = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txt_unidadeId = new System.Windows.Forms.TextBox();
			this.grpBox_Menu = new System.Windows.Forms.GroupBox();
			this.btn_telaLogin = new System.Windows.Forms.Button();
			this.btn_sair = new System.Windows.Forms.Button();
			this.btn_comChave = new System.Windows.Forms.Button();
			this.btn_semChave = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btn_cadastrarProfessor = new System.Windows.Forms.Button();
			this.txt_nomeProfessor = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txt_turmaId = new System.Windows.Forms.TextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.label5 = new System.Windows.Forms.Label();
			this.btn_cadastrarSalario = new System.Windows.Forms.Button();
			this.txt_valorSalario = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.txt_professorId = new System.Windows.Forms.TextBox();
			this.grpBox_turma.SuspendLayout();
			this.grpBox_Menu.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// grpBox_turma
			// 
			this.grpBox_turma.Controls.Add(this.label3);
			this.grpBox_turma.Controls.Add(this.btn_CadastrarTurma);
			this.grpBox_turma.Controls.Add(this.txt_serieTurma);
			this.grpBox_turma.Controls.Add(this.label2);
			this.grpBox_turma.Controls.Add(this.txt_unidadeId);
			this.grpBox_turma.Location = new System.Drawing.Point(12, 95);
			this.grpBox_turma.Name = "grpBox_turma";
			this.grpBox_turma.Size = new System.Drawing.Size(831, 125);
			this.grpBox_turma.TabIndex = 49;
			this.grpBox_turma.TabStop = false;
			this.grpBox_turma.Text = "Turma";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(6, 31);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(31, 15);
			this.label3.TabIndex = 44;
			this.label3.Text = "serie";
			// 
			// btn_CadastrarTurma
			// 
			this.btn_CadastrarTurma.Location = new System.Drawing.Point(6, 78);
			this.btn_CadastrarTurma.Name = "btn_CadastrarTurma";
			this.btn_CadastrarTurma.Size = new System.Drawing.Size(819, 25);
			this.btn_CadastrarTurma.TabIndex = 46;
			this.btn_CadastrarTurma.Text = "Cadastrar";
			this.btn_CadastrarTurma.UseVisualStyleBackColor = true;
			this.btn_CadastrarTurma.Click += new System.EventHandler(this.btn_CadastrarTurma_Click);
			// 
			// txt_serieTurma
			// 
			this.txt_serieTurma.Location = new System.Drawing.Point(6, 49);
			this.txt_serieTurma.Name = "txt_serieTurma";
			this.txt_serieTurma.Size = new System.Drawing.Size(200, 23);
			this.txt_serieTurma.TabIndex = 45;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(212, 31);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(65, 15);
			this.label2.TabIndex = 42;
			this.label2.Text = "unidade_id";
			// 
			// txt_unidadeId
			// 
			this.txt_unidadeId.Location = new System.Drawing.Point(212, 49);
			this.txt_unidadeId.Name = "txt_unidadeId";
			this.txt_unidadeId.Size = new System.Drawing.Size(200, 23);
			this.txt_unidadeId.TabIndex = 43;
			// 
			// grpBox_Menu
			// 
			this.grpBox_Menu.Controls.Add(this.btn_telaLogin);
			this.grpBox_Menu.Controls.Add(this.btn_sair);
			this.grpBox_Menu.Controls.Add(this.btn_comChave);
			this.grpBox_Menu.Controls.Add(this.btn_semChave);
			this.grpBox_Menu.Location = new System.Drawing.Point(12, 12);
			this.grpBox_Menu.Name = "grpBox_Menu";
			this.grpBox_Menu.Size = new System.Drawing.Size(834, 60);
			this.grpBox_Menu.TabIndex = 48;
			this.grpBox_Menu.TabStop = false;
			this.grpBox_Menu.Text = "Menu";
			// 
			// btn_telaLogin
			// 
			this.btn_telaLogin.Location = new System.Drawing.Point(6, 22);
			this.btn_telaLogin.Name = "btn_telaLogin";
			this.btn_telaLogin.Size = new System.Drawing.Size(200, 25);
			this.btn_telaLogin.TabIndex = 21;
			this.btn_telaLogin.Text = "Tela de login";
			this.btn_telaLogin.UseVisualStyleBackColor = true;
			this.btn_telaLogin.Click += new System.EventHandler(this.btn_telaLogin_Click);
			// 
			// btn_sair
			// 
			this.btn_sair.Location = new System.Drawing.Point(624, 22);
			this.btn_sair.Name = "btn_sair";
			this.btn_sair.Size = new System.Drawing.Size(200, 25);
			this.btn_sair.TabIndex = 20;
			this.btn_sair.Text = "Sair da aplicação";
			this.btn_sair.UseVisualStyleBackColor = true;
			this.btn_sair.Click += new System.EventHandler(this.btn_sair_Click);
			// 
			// btn_comChave
			// 
			this.btn_comChave.Location = new System.Drawing.Point(418, 22);
			this.btn_comChave.Name = "btn_comChave";
			this.btn_comChave.Size = new System.Drawing.Size(200, 25);
			this.btn_comChave.TabIndex = 19;
			this.btn_comChave.Text = "Cadastro com chave estrangeira";
			this.btn_comChave.UseVisualStyleBackColor = true;
			this.btn_comChave.Click += new System.EventHandler(this.btn_comChave_Click);
			// 
			// btn_semChave
			// 
			this.btn_semChave.Location = new System.Drawing.Point(212, 22);
			this.btn_semChave.Name = "btn_semChave";
			this.btn_semChave.Size = new System.Drawing.Size(200, 25);
			this.btn_semChave.TabIndex = 16;
			this.btn_semChave.Text = "Cadastro sem chave estrangeira";
			this.btn_semChave.UseVisualStyleBackColor = true;
			this.btn_semChave.Click += new System.EventHandler(this.btn_semChave_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.btn_cadastrarProfessor);
			this.groupBox1.Controls.Add(this.txt_nomeProfessor);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.txt_turmaId);
			this.groupBox1.Location = new System.Drawing.Point(12, 226);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(831, 125);
			this.groupBox1.TabIndex = 50;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Professor";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 31);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(38, 15);
			this.label1.TabIndex = 44;
			this.label1.Text = "nome";
			// 
			// btn_cadastrarProfessor
			// 
			this.btn_cadastrarProfessor.Location = new System.Drawing.Point(6, 78);
			this.btn_cadastrarProfessor.Name = "btn_cadastrarProfessor";
			this.btn_cadastrarProfessor.Size = new System.Drawing.Size(819, 25);
			this.btn_cadastrarProfessor.TabIndex = 46;
			this.btn_cadastrarProfessor.Text = "Cadastrar";
			this.btn_cadastrarProfessor.UseVisualStyleBackColor = true;
			this.btn_cadastrarProfessor.Click += new System.EventHandler(this.btn_cadastrarProfessor_Click);
			// 
			// txt_nomeProfessor
			// 
			this.txt_nomeProfessor.Location = new System.Drawing.Point(6, 49);
			this.txt_nomeProfessor.Name = "txt_nomeProfessor";
			this.txt_nomeProfessor.Size = new System.Drawing.Size(200, 23);
			this.txt_nomeProfessor.TabIndex = 45;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(212, 31);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(54, 15);
			this.label4.TabIndex = 42;
			this.label4.Text = "turma_id";
			// 
			// txt_turmaId
			// 
			this.txt_turmaId.Location = new System.Drawing.Point(212, 49);
			this.txt_turmaId.Name = "txt_turmaId";
			this.txt_turmaId.Size = new System.Drawing.Size(200, 23);
			this.txt_turmaId.TabIndex = 43;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.label5);
			this.groupBox2.Controls.Add(this.btn_cadastrarSalario);
			this.groupBox2.Controls.Add(this.txt_valorSalario);
			this.groupBox2.Controls.Add(this.label6);
			this.groupBox2.Controls.Add(this.txt_professorId);
			this.groupBox2.Location = new System.Drawing.Point(6, 357);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(831, 125);
			this.groupBox2.TabIndex = 51;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "salario";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(6, 31);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(33, 15);
			this.label5.TabIndex = 44;
			this.label5.Text = "valor";
			// 
			// btn_cadastrarSalario
			// 
			this.btn_cadastrarSalario.Location = new System.Drawing.Point(6, 78);
			this.btn_cadastrarSalario.Name = "btn_cadastrarSalario";
			this.btn_cadastrarSalario.Size = new System.Drawing.Size(819, 25);
			this.btn_cadastrarSalario.TabIndex = 46;
			this.btn_cadastrarSalario.Text = "Cadastrar";
			this.btn_cadastrarSalario.UseVisualStyleBackColor = true;
			this.btn_cadastrarSalario.Click += new System.EventHandler(this.btn_cadastrarSalario_Click);
			// 
			// txt_valorSalario
			// 
			this.txt_valorSalario.Location = new System.Drawing.Point(6, 49);
			this.txt_valorSalario.Name = "txt_valorSalario";
			this.txt_valorSalario.Size = new System.Drawing.Size(200, 23);
			this.txt_valorSalario.TabIndex = 45;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(212, 31);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(71, 15);
			this.label6.TabIndex = 42;
			this.label6.Text = "professor_id";
			// 
			// txt_professorId
			// 
			this.txt_professorId.Location = new System.Drawing.Point(212, 49);
			this.txt_professorId.Name = "txt_professorId";
			this.txt_professorId.Size = new System.Drawing.Size(200, 23);
			this.txt_professorId.TabIndex = 43;
			// 
			// FrmComChave
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(856, 622);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.grpBox_turma);
			this.Controls.Add(this.grpBox_Menu);
			this.Name = "FrmComChave";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Cadastro com chave estrangeira";
			this.grpBox_turma.ResumeLayout(false);
			this.grpBox_turma.PerformLayout();
			this.grpBox_Menu.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox grpBox_turma;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btn_CadastrarTurma;
		private System.Windows.Forms.TextBox txt_serieTurma;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txt_unidadeId;
		private System.Windows.Forms.GroupBox grpBox_Menu;
		private System.Windows.Forms.Button btn_telaLogin;
		private System.Windows.Forms.Button btn_sair;
		private System.Windows.Forms.Button btn_comChave;
		private System.Windows.Forms.Button btn_semChave;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btn_cadastrarProfessor;
		private System.Windows.Forms.TextBox txt_nomeProfessor;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txt_turmaId;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btn_cadastrarSalario;
		private System.Windows.Forms.TextBox txt_valorSalario;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txt_professorId;
	}
}